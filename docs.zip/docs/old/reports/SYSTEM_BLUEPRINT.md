# SYSTEM_BLUEPRINT.md

> Single source of truth — Ahram Distribution Management System

---

## ACTIVE_TARGETS

| Property | Value |
|---|---|
| **Database** | `gbcbejejgpvltuhbztbx` |
| **Repository** | `D:\Ahram Distribution\ahram-distribution` |
| **Workspace** | `D:\Ahram Distribution\workspace` |
| **Status** | `ACTIVE` |

### Repository Protection Rule

Any database, repository, archive, backup, export, imported copy, legacy project, historical dump, temporary clone, or workspace copy other than the ACTIVE_TARGETS listed above must be treated as **reference-only**. No implementation, migration, deployment, schema modification, governance change, runtime change, or feature development may be executed against them.

---

## Project Operating Constitution

The project is no longer in discovery phase. The project is in **controlled execution phase**.

### A. Source Of Truth

1. **SYSTEM_BLUEPRINT.md** is the authoritative operational document.
2. **PROJECT_CHANGELOG.md** is the authoritative historical document.
3. **ACTIVE_TARGETS** is the authoritative environment definition.
4. No task may ignore these sources.

### B. Default Behavior

1. Future work must begin from documented project knowledge.
2. Assume project knowledge already exists.
3. Do not rebuild understanding from the repository.
4. Do not rediscover architecture.
5. Do not re-evaluate completed phases.
6. Do not perform exploratory reviews.

### C. Repository Restrictions

Forbidden by default without explicit user authorization:

- Repository Audit
- Repository Discovery
- Repository Exploration
- Broad File Inspection
- Architecture Review
- Governance Review
- Re-analysis of completed modules
- Pattern Hunting
- Technology Surveys

### D. Scope Discipline

1. Work only inside the scope explicitly requested.
2. Do not expand scope.
3. Do not create additional phases.
4. Do not introduce adjacent features.
5. Do not redesign approved business decisions.
6. Do not create alternative architectures unless requested.

### E. Missing Information Protocol

1. If a required business decision is missing: **Stop**.
2. Ask a focused question.
3. Do not assume.
4. Do not invent.

### F. Documentation Governance

Every completed task must update:

- SYSTEM_BLUEPRINT.md
- PROJECT_CHANGELOG.md

No task is complete before documentation is updated.

### G. Conflict Protocol

1. If implementation conflicts with documentation: **Stop**.
2. Report conflict.
3. Wait for decision.
4. Do not choose a side.

### H. Execution Philosophy

1. Prefer execution over investigation.
2. Prefer implementation over analysis.
3. Prefer targeted validation over repository review.
4. Prefer documented knowledge over rediscovery.

---

## Project Identity

| Property | Value |
|---|---|
| **Project Name** | Ahram Distribution Management System |
| **Repository** | `ahram-distribution/` |
| **Type** | Distribution/Wholesale Management Platform |
| **Stack** | React 19 + Vite 8 + TypeScript 6 + Supabase (PostgreSQL) |
| **Frontend** | SPA (Vite), Tailwind CSS v4, React Router v7, Zustand |
| **Backend** | Supabase PostgreSQL (SECURITY DEFINER RPCs, no RLS) |
| **Auth** | Custom session-based (app.sessions table), bcrypt (crypt extension) |
| **Target DB** | `gbcbejejgpvltuhbztbx` |
| **Anon Key** | `sb_publishable_-7En88KJzEiVB8dTFfJXGg_QsGx7loF` |
| **Service Token** | `sbp_2e6cbc99d376b1d05db933f3e0ce874e5fc7f8f3` (Node.js only, never frontend) |
| **Default Password** | `123321` |

---

## Business Description

Ahram Distribution is a wholesale distribution company managing:
- **Products** — multi-unit (piece, dozen, carton), multi-tier pricing, deals, auctions
- **Customers** — pharmacies, wholesalers, retailers, clinics with credit terms
- **Orders** — multi-item with discounts, status workflow, revision history
- **Visits** — field sales rep visits with geolocation check-in/out
- **Collections** — cash/cheque/bank-transfer/deposit with reconciliation
- **Returns** — return merchandise authorization with inspection/approval
- **Delivery** — proxy-based (status-driven, no dedicated delivery_tracking table)
- **Inventory** — stock tracking across warehouses

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────────┐
│                    React SPA (Vite)                       │
│  ┌─────────┐ ┌──────────┐ ┌──────────┐ ┌─────────────┐ │
│  │  Auth    │ │  Pages   │ │Components│ │   Stores    │ │
│  │ (custom) │ │(role-routed)│ (shared)  │ (Zustand)   │ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └──────┬──────┘ │
│       └────────────┴────────────┴──────────────┘         │
│                         │                                 │
│              supabase-js (anon key only)                  │
└─────────────────────────┬────────────────────────────────┘
                          │ RPC calls
┌─────────────────────────▼────────────────────────────────┐
│               Supabase PostgreSQL                          │
│  ┌─────────────────────────────────────────────────────┐ │
│  │  SECURITY DEFINER Functions (governed_*)             │ │
│  │  • Visibility: get_governed_{entity}                 │ │
│  │  • Write: governed_{entity}_{action}                 │ │
│  │  • Dashboard: get_dashboard_{dashboard}              │ │
│  │  • Auth: login, logout, validate_session             │ │
│  ├─────────────────────────────────────────────────────┤ │
│  │  Tables: employees, customers, orders, order_items,  │ │
│  │  visits, collections, returns, return_items,         │ │
│  │  products, product_prices, deals, auctions, tiers,   │ │
│  │  roles, role_capabilities, capabilities, inventory   │ │
│  ├─────────────────────────────────────────────────────┤ │
│  │  Audit: order_status_history, order_modification_    │ │
│  │  history, customer_ownership_history, visits          │ │
│  └─────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────┘
```

### Key Design Decisions

- **No RLS** — Governance enforced exclusively via SECURITY DEFINER RPCs
- **No JWT** — Custom session tokens in `app.sessions` table (UUID v4)
- **Anon key only in frontend** — Service role key NEVER exposed
- **No direct table access** — All data access through governed RPCs
- **Inline CTE pattern** — Visibility determined by recursive employee subtree CTE (not `get_visible_employee_ids()` due to SETOF uuid type limitation)

---

## Runtime Architecture

### Frontend Routes

| Path | Page | Access |
|---|---|---|
| `/login` | LoginPage | Unauthenticated |
| `/dashboard` | DashboardPage | All employees (role-aware routing) |
| `/storefront` | StorefrontPage | All |
| `/cart` | CartPage | All |
| `/checkout` | CheckoutPage | All |
| `/order-review` | OrderReviewPage | All |
| `/order-success` | OrderSuccessPage | All |
| `/orders` | OrdersPage | All |
| `/orders/:id` | OrderDetailPage | All |
| `/orders/:id/edit` | OrderEditPage | All |
| `/visits` | VisitsPage | Sales roles |
| `/visits/new` | NewVisitPage | Sales roles |
| `/visits/:id` | VisitDetailPage | Sales roles |
| `/collections` | CollectionsPage | Finance/Sales roles |
| `/collections/new` | NewCollectionPage | Finance/Sales roles |
| `/returns` | ReturnsPage | Sales/Returns roles |
| `/returns/:id` | ReturnDetailPage | Sales/Returns roles |
| `/customers` | CustomersPage | All employees |
| `/customers/:id/analytics` | CustomerAnalyticsPage | All employees (customer intelligence card) |
| `/analytics/customers` | AnalyticsListPage | All employees (ranked list with risk flags) |
| `/products` | ProductsPage | All |
| `/deals` | DealsPage | Sales |
| `/daily-deals` | DailyDealsPage | All |
| `/daily-deals/:id` | DailyDealDetailPage | All |
| `/daily-deals/manage` | DailyDealsManagementPage | Sales Manager and above (deals.manage) |
| `/auctions` | AuctionsPage | All (unauthenticated view) |
| `/auctions/:id` | AuctionDetailPage | All (unauthenticated view, bid/purchase require auth) |
| `/credit` | CustomerCreditPage (credit dashboard) | All authenticated |
| `/customer/credit` | Redirects to `/credit` | All authenticated |
| `/credit/manage` | CreditManagementPage (employee dashboard) | `credit.manage` |
| `/credit/programs` | CreditProgramsPage | `credit.manage` |
| `/credit/applications` | CreditApplicationsPage | `credit.view` |
| `/credit/applications/:id` | CreditReviewPage | `credit.review` |
| `/warehouse` | WarehousePage (5-tab operations) | Warehouse Preparation Manager (all tabs); Reviewers (review_queue tab) |
| `/warehouse/review` | WarehouseReviewPage | Approved reviewers only |
| `/warehouse/prep/:id` | WarehousePrepDetail | All warehouse roles |
| `/account` | AccountPage | All |

### Auth Flow

```
Login(phone, password) → public.login() → api.login()
  → Verify in public.identities (phone + bcrypt hash)
  → Lookup employee/customer by identity_id
  → Create session in app.sessions (UUID token, 24h expiry)
  → Return token + employee/customer + roles
  → Frontend stores token in localStorage
  → All subsequent RPC calls pass p_token parameter
```

### Session Validation

```
Every governed function:
  1. SELECT * FROM app.sessions WHERE token = p_token AND expires_at > now()
  2. IF NOT FOUND → return empty / raise INVALID_SESSION
  3. IF identity_type = 'customer' → customer-scoped visibility
  4. ELSE → employee-scoped visibility via subtree CTE
```

---

## Ownership Model

| Entity | Owned By | Owner Field |
|---|---|---|
| Orders | Employee (SALES_REP who created) | `owner_id` (references employees) |
| Customers | Employee (who registered/owns account) | `owner_id` (references employees) |
| Visits | Employee (who conducted visit) | `employee_id` |
| Collections | Employee (who collected) | `created_by` |
| Returns | Employee (who processed) | `created_by` |

### Visibility Rules

1. **SUPER_ADMIN / CHAIRMAN / ADMIN** — full visibility (all records) via role-based check
2. **Manager** — sees own records + subordinates' records (recursive subtree)
3. **SALES_REP** — sees only own records
4. **Customer** — sees only own records (filtered by `customer_id`)
5. **Shared Unit (WRQ1002 على سعيد, WRQ1004 محمود سعيد)** — sees subtree under their shared manager (WRQ1003 محمد سعيد)

---

## Governance Model

### Capability System

- **23 roles** defined in `public.roles`
- **39 capabilities** defined in `public.capabilities`
- **318 role-capability mappings** in `public.role_capabilities` / `public.employee_roles`
- Capabilities follow `<entity>.<action>` pattern (e.g., `orders.create`, `customers.read`)

### Capability Categories

| Category | Capabilities |
|---|---|
| Orders | create, read, update, delete, approve |
| Customers | create, read, update, delete |
| Collections | create, read, update, delete |
| Returns | create, read, update, approve |
| Visits | create, read, update |
| Products | create, read, update, delete |
| Inventory | read, update |
| Employees | create, read, update, delete |
| Reports | read, export |
| Pricing | read, update |
| Admin | roles, settings, users |
| Tiers | read, update |

### Write Enforcement

All write operations go through `governed_{entity}_{action}()` functions that:
1. Validate session token
2. Check capability via `check_capability(p_token, p_capability)`
3. Verify ownership scope (can only modify own/subordinate records)
4. Populate audit tables (`order_status_history`, `customer_ownership_history`, etc.)

### Superior Role Visibility Check

Added as part of operational runtime fixes:
- Users with roles `SUPER_ADMIN`, `CHAIRMAN`, or `ADMIN` bypass subtree visibility
- All 15 governed functions + all 4 dashboard functions have this check
- Check performed via: `SELECT EXISTS(SELECT 1 FROM employee_roles er JOIN roles r ON r.id = er.role_id WHERE er.employee_id = v_session.employee_id AND r.name IN ('SUPER_ADMIN','CHAIRMAN','ADMIN'))`

---

## Sales Authority Rules

| Role / Employee | Order Creation Scope | Visit Creation Scope |
|---|---|---|
| Chairman (WRQ1003 محمد سعيد) | Any customer visible within governance scope | Any customer visible within governance scope |
| SUPER_ADMIN (WRQ1006 ياسر توفيق) | Any customer visible within governance scope | Any customer visible within governance scope |
| ADMIN (ADMIN-001) | Any customer visible within governance scope | Any customer visible within governance scope |
| على سعيد (WRQ1002) — Shared Unit | Any customer visible under shared manager subtree | Any customer visible under shared manager subtree |
| محمود سعيد (WRQ1004) — Shared Unit | Any customer visible under shared manager subtree | Any customer visible under shared manager subtree |
| Sales Supervisor (REP001 خالد سعيد) | Customers owned by self + direct SALES_REP team | Visits within governed team visibility scope |
| SALES_REP | Directly owned customers only | Directly owned customers only |

### Scope Rules
1. **Chairman / SUPER_ADMIN / ADMIN** — full-scope order and visit creation across all visible customers within their governance scope (bypasses subtree).
2. **Shared Management Unit (WRQ1002 على سعيد, WRQ1004 محمود سعيد)** — order and visit creation scoped to customers visible under their shared manager (WRQ1003 محمد سعيد) subtree per existing shared unit rule.
3. **Sales Supervisor (REP001 خالد سعيد)** — order and visit creation limited to customers owned by himself or his directly managed SALES_REP team.
4. **SALES_REP** — order and visit creation limited to directly owned customers (owner_id = self).

---

## Organization Structure

```
ياسر توفيق (WRQ1006) [SUPER_ADMIN] — root
├── admin (ADMIN-001) [ADMIN]
├── بسام (WRQ1001) [Warehouse Preparation Manager] — 5 caps
├── خالد سعيد (REP001) [SALES_SUPERVISOR] — manages 7 SALES_REPs
│   ├── اسلام احمد (REP005) [SALES_REP]
│   ├── اسلام حمدى (REP007) [SALES_REP]
│   ├── جلال محمد (REP008) [SALES_REP]
│   ├── حسن بكر (REP004) [SALES_REP]
│   ├── علاء موسى (REP006) [SALES_REP]
│   ├── عمر محسن (REP003) [SALES_REP]
│   └── محمد حافظ (REP002) [SALES_REP]
└── محمد سعيد (WRQ1003) [CHAIRMAN] — 39 caps (=SUPER_ADMIN)
    ├── على سعيد (WRQ1002) [EXECUTIVE_MANAGER] — shared unit (36 caps)
    │   ├── محمد عبد الباسط (REP-001) [Transportation Manager] — 7 caps
    │   └── هادى سعيد (WRQ1005) [EXECUTIVE_SUPERVISOR] — 13 caps
    └── محمود سعيد (WRQ1004) [EXECUTIVE_MANAGER, Sales Manager] — shared unit (60 caps)
```

**Total**: 16 employees, 4 levels of hierarchy

---

## Capability Model (Key Roles)

| Role | Caps | Key Capabilities |
|---|---|---|
| SUPER_ADMIN | 39 | All CRUD + admin + approve |
| CHAIRMAN | 39 | All CRUD + admin + approve |
| ADMIN | 39 | All CRUD + admin + approve |
| EXECUTIVE_MANAGER | 36 | All except admin.* |
| Sales Manager | 24 | Orders/Visits/Customers CRUD + approve |
| SALES_SUPERVISOR | 17 | Orders/Visits/Customers (no delete) |
| SALES_REP | 14 | Create orders/visits/collections, read customers |
| Warehouse Prep Manager | 5 | inventory.read/update, orders.read, products.read |
| Transportation Manager | 7 | customers.create, collections.read + base |
| EXECUTIVE_SUPERVISOR | 13 | customers.create, read; visits/orders create/read |

---

## Pricing Model

- **Tier-based pricing**: Each product can have different prices per customer tier
- **Unit types**: piece (قطعة), dozen (دستة), carton (كرتونة)
- **Deals**: Temporary price promotions
- **Auctions**: Bid-based pricing for select products
- **Discounts**: Per-order discount_amount applied during checkout

### Product Availability Rule

A product is sellable if at least one sellable unit has a valid selling price > 0.

**Unit price derivation** (from `products.carton_price` + `products.carton_quantity`):
- Carton: valid if `carton_price > 0` → price = `carton_price`
- Piece: valid if `carton_price > 0 AND carton_quantity > 0` → price = `carton_price / carton_quantity`
- Dozen: valid if `carton_price > 0 AND carton_quantity > 0` → price = piece_price × 12

**Availability states**:
- **No priced units** (`carton_price <= 0` or all unit types invalid): product visible in catalog, displays "غير متوفر حالياً", cannot be added to cart
- **One priced unit**: only that unit type is selectable in dropdown; add-to-cart allowed
- **Mixed availability**: only unit types with valid prices appear in dropdown; others hidden
- **Sales blocked** (`sales_blocked = true`): product displays blocked message regardless of pricing

**Enforcement layers**:
1. Storefront product card — per-unit dropdown only shows valid unit types
2. Add-to-cart — rejects products/units without valid prices
3. Cart page — validates availability before proceeding to order review
4. Checkout — validates all items before order submission

---

## Customer Model

- **Business Type**: `business_type` ENUM (wholesaler, distributor, cosmetics_store, supermarket, hypermarket, perfume_store, pharmacy, warehouse, other)
- **Responsible Person**: `customer.responsible_name` — full name of the responsible contact
- **Credit**: credit_limit, credit_days, running balance
- **Ownership**: Each customer assigned to an employee (owner_id)
- **Addresses**: Multiple addresses per customer (`customer_addresses` table)
- **Location**: Each customer linked to a unified location via `customers.location_id → unified_locations.id`
- **Status**: Active/inactive with last-activity tracking
- **Registration**: Immediate activation via `register_customer` RPC (no approval queue). Mandatory GPS location (≤20m accuracy), Egyptian mobile (11 digits, 01x prefix), 6-digit numeric password.

## Unified Location Standard

### Architecture

One `unified_locations` table reused across ALL modules. No per-module location tables. No duplicate location systems.

```sql
unified_locations
├── id                uuid PK
├── latitude          numeric NOT NULL
├── longitude         numeric NOT NULL
├── accuracy_meters   numeric
├── google_maps_url   text (GENERATED ALWAYS AS ... STORED)
├── formatted_address text
├── captured_at       timestamptz NOT NULL
└── created_at        timestamptz NOT NULL
```

### URL Canonical Format

```
https://www.google.com/maps?q={lat},{lng}
```

Generated:
- At the DB level via `GENERATED ALWAYS AS` stored column
- In frontend code exclusively via `locationService.buildGoogleMapsUrl()`

No hardcoded URL strings are permitted.

### Entity Linking

Each entity table adds its own FK to `unified_locations`:

| Entity | FK Column |
|--------|-----------|
| `customers` | `location_id` |
| `employees` (future) | `location_id` |
| `visits` (future) | `start_location_id`, `end_location_id` |
| `delivery_tracking` (future) | `location_id` |

### Shared Location Service

**File**: `src/services/location.ts`

| Method | Purpose |
|--------|---------|
| `buildGoogleMapsUrl(lat, lng)` | Returns canonical Google Maps URL |
| `openGoogleMaps(lat, lng)` | Opens Google Maps in new tab |
| `formatAccuracy(accuracy)` | Returns `{ label, className, detail }` for accuracy level |
| `fetchLocation(id)` | Fetches a single unified_locations record |
| `fetchLocations(ids)` | Batch-fetches multiple unified_locations records |

### Accuracy Classification

| Range | Display |
|-------|---------|
| ≤ 10m | دقة ممتازة (green) |
| 11–20m | دقة جيدة (amber) |
| > 20m | دقة ضعيفة (red) — rejected during registration |
| NULL | غير محدد |

### Customer Location UX Standard

Whenever customer location is displayed, show exactly:
1. **العنوان** — `formatted_address` from unified_locations (or `customer_addresses` fallback)
2. **دقة الموقع** — accuracy label with meter value
3. **زر فتح الموقع** — prominent action button linking to Google Maps navigation

### Index Strategy

`unified_locations` has only a PK index on `id`. No indexes on `latitude`/`longitude` are added because:
- No geospatial querying is performed (no radius search, no routing)
- The only access pattern is point lookup by `id` via FK
- Indexes would be purely speculative at this stage

---

## Operational Runtime Model

### Dashboards (4 role-based)

| Dashboard | Key Counters | Consumer |
|---|---|---|
| Sales | today_orders, pending_followup, inactive_customers, today_visits, today_collections | SALES_REP, SALES_SUPERVISOR |
| Warehouse | waiting_preparation, in_preparation, ready_shipping | Warehouse Prep Manager |
| Transport | ready_delivery, out_delivery, delivery_queue, collection_queue | Transportation Manager |
| Management | total/pending/approved orders, total_customers, active_visits, pending collections/returns, today orders/visits | SUPER_ADMIN, CHAIRMAN, ADMIN |

### Drill-Down Navigation

All dashboard counter widgets navigate to filtered list pages via `?filter=` URL params:
- `/orders?filter=today|pending|approved|preparing|delivering|undelivered`
- `/visits?filter=today|active`
- `/collections?filter=today|pending`
- `/returns?filter=pending`
- `/customers?filter=inactive`

### Proxy Status Mappings (no DB schema migration allowed)

| Dashboard Counter | DB Query (current — broken) | Fixed Query (Phase 1) |
|---|---|---|
| waiting_preparation | `status = 'approved' AND delivered_at IS NULL` | `status = 'approved' AND NOT EXISTS(preparation_records)` |
| in_preparation | `status IN ('draft','reviewing')` | `preparation_records.status = 'in_progress'` |
| ready_shipping | `status = 'submitted'` | `preparation_records.status = 'reviewed'` |
| ready_delivery | `status = 'approved' AND delivered_at IS NULL` | `status = 'approved' AND no delivery_tracking record` |
| out_delivery | `status IN ('approved','submitted') AND delivered_at IS NULL` | `delivery_tracking.status IN ('assigned','out_for_delivery')` |
| delivery_queue | `status NOT IN ('draft','cancelled') AND delivered_at IS NULL` | `delivery_tracking.status NOT IN ('delivered','failed','returned')` |

---

## Authentication Model

- **Custom session auth** (not Supabase Auth)
- `public.identities` table: phone, bcrypt password_hash, identity_type (employee/customer)
- `app.sessions` table: token (UUID), identity_id, employee_id/customer_id, expires_at
- Password hashing via `extensions.crypt()` (pgcrypt extension in `extensions` schema)
- Session expires after 24 hours
- Frontend persists token in localStorage
- No refresh token mechanism (re-login required)

---

## Completed Phases

| Phase | Description | Status |
|---|---|---|
| Schema Foundation | Base tables, types, relationships | ✅ Done |
| Identity & Governance | Auth, roles, capabilities, visibility | ✅ Done |
| Customer Management | CRUD, tiers, addresses, ownership | ✅ Done |
| Order Management | Multi-item, discounts, revisions, approval | ✅ Done |
| Collections & Treasury | Cash/bank/cheque/deposit, reconciliation | ✅ Done |
| Returns | RMA, inspection, approval, credit notes | ✅ Done |
| Visits | Check-in/out, geolocation, results | ✅ Done |
| Pricing & Tiers | Tier-based pricing, unit flexibility | ✅ Done |
| Governance Phase 1 | Visibility functions (inline CTE fix) | ✅ Done |
| Governance Phase 2 | Write enforcement (20 governed write functions) | ✅ Done |
| Auth Finalization | Custom login/logout, session validation | ✅ Done |
| Shared Management Unit | Ali/Mahmoud under Mohamed Said | ✅ Done |
| Chairman Authority | CHAIRMAN role = SUPER_ADMIN (39 caps) | ✅ Done |
| Organization Report | Employee hierarchy, org chart delivered | ✅ Done |
| Operational Dashboards | 4 dashboard functions + frontend pages | ✅ Done |
| Operational Runtime Fixes | Capability-aware visibility, governance filtering | ✅ Done |
| Repository Hygiene | Clean structure, workspace isolation | ✅ Done |
| Customer Analytics Phase 1 | DB analytics functions (6 functions) | ✅ Done |
| Customer Analytics Phase 2 | Frontend analytics pages (2 pages) | ✅ Done |
| Product Availability Enforcement | Storefront availability validation (4 layers) | ✅ Done |
| Credit Workflow Phase 1 Foundation | Credit programs, applications, contracts, approval workflow, dashboard, follow-up queue | ✅ Done |
| Delivery & Collection Runtime | Delivery tracking, assignment, lifecycle, fail workflow, proof of delivery, collection follow-up, transport dashboard | ✅ Done |
| Warehouse Runtime Phase 1 | Preparation lifecycle, queue, dashboard, analytics, audit trail, governance | ✅ Done |
| Warehouse Runtime Phase 2 | Operations screens (5-tab, review, detail, histories) | ✅ Done |
| Warehouse Runtime Phase 3 | Exception handling (exception recording, fail workflow, return workflow, exception queue) | ✅ Done |
| Mobile-First UI Blocking Fixes | Dashboard routing, OrderEditPage real data, VisitsPage customer name, WarehousePage mobile-first cards, WarehouseReviewPage mobile-first cards | ✅ Done |
| Daily Deals Module | Daily Deal (صفقة اليوم) as dedicated commercial package with governed CRUD, storefront, cart/order integration, inventory deduction, test deal | ✅ Done |
| Auction Module V2 | Mobile-first Auction Room with Realtime bidding, activity feed, participant management, gov RPCs, comprehensive test seed | ✅ Done |
| Credit Program Module V2 | Credit account management, invoice/cheque tracking, credit reservation flow, payment recording, auto-suspension, full frontend dashboard | ✅ Done |

---

## Pending Phases

| Phase | Description | Priority |
|---|---|---|
| Inventory | Full inventory tracking, stock moves | Medium |
| Notifications | Real-time alerts for orders/approvals | Low |
| Reporting | Advanced analytics, exports | Low |
| Testing | Comprehensive test suite | Medium |

---

## Delivery & Collection Runtime

### Delivery Lifecycle
`approved` → `dispatched` (delivery_tracking created) → `out_for_delivery` → `delivered` OR `failed` OR `returned`

Order `status` uses native `dispatched` and `delivered` values (already in check constraint). Delivery tracking managed via `delivery_tracking` table.

### Database Objects
- `delivery_tracking` table: id, order_id (unique FK), status (assigned/out_for_delivery/delivered/failed/returned), assigned_to, assigned_by, assigned_at, started_at, completed_at, failure_reason, failure_notes, notes, returned_at, created_at, updated_at

### Capabilities (3 new)
- `delivery.dispatch` — Transportation Manager, SUPER_ADMIN/CHAIRMAN/ADMIN, EXECUTIVE_MANAGER, Sales Manager
- `delivery.deliver` — same as dispatch
- `delivery.view` — all roles

### Governed Functions (7 delivery + 2 collection)
- `governed_dispatch_order(p_token, p_order_id, p_assigned_to)` → creates delivery_tracking, sets order to `dispatched`
- `governed_assign_delivery(p_token, p_delivery_id, p_employee_id)` → reassigns delivery
- `governed_start_delivery(p_token, p_delivery_id)` → sets `out_for_delivery`
- `governed_complete_delivery(p_token, p_delivery_id, p_notes)` → sets `delivered`, order to `delivered`, sets `delivered_at`
- `governed_fail_delivery(p_token, p_delivery_id, p_reason, p_notes)` → sets `failed` with reason
- `governed_return_delivery(p_token, p_delivery_id, p_notes)` → sets `returned`, resets order to `approved`
- `get_governed_deliveries(p_token, p_status_filter)` → list with governance
- `get_delivery_dashboard_stats(p_token)` → dashboard counters
- `get_collection_followup_queue(p_token)` → collection follow-up with due/overdue tracking

### Failed Delivery Reasons
customer_unavailable, customer_rejected, address_issue, payment_issue, returned_to_warehouse, other

### Transport Dashboard Counters (8)
ready_delivery, out_delivery, delivery_queue, delivered_today, failed, collection_queue, pending_collections, overdue_collections

### Frontend Pages
- `/delivery` — DeliveryPage: queue with status filters, assign/start actions
- `/delivery/:id` — DeliveryDetailPage: start, complete, fail, return actions
- `/collections/followup` — CollectionFollowupPage: pending/overdue collections queue

---

## Warehouse Runtime Phase 1

### Preparation Lifecycle

Preparation state stored in `preparation_records` table (separate from order status). Order `status` transitions from `approved` → `preparing` on start (recorded in `order_status_history`).

| Stage | preparation_records.status | Meaning |
|---|---|---|
| waiting | (no record) | Approved, not yet prepared |
| in_progress | in_progress | Preparation started, items being picked/packed |
| completed | completed | Packing complete, awaiting review |
| reviewed | reviewed | Approved for delivery runtime handoff |
| failed | failed | Cancelled — shortage/exception |

### Operational Roles

| Employee | Code | Role | Scope |
|---|---|---|---|
| بسام | WRQ1001 | Warehouse Preparation Manager | Start, Complete, Cancel |
| محمد عبد الباسط | REP-001 | Transportation Manager | Review |
| هادى سعيد | WRQ1005 | Executive Supervisor | Review |
| على سعيد | WRQ1002 | Executive Manager | Review |
| محمود سعيد | WRQ1004 | Executive Manager | Review |
| محمد سعيد | WRQ1003 | CHAIRMAN | Review (bypass) |
| ياسر توفيق | WRQ1006 | SUPER_ADMIN | Review (bypass) |

### Database Objects
- `preparation_status` enum: `in_progress`, `completed`, `reviewed`, `failed`
- `preparation_records`: id, order_id (unique FK), status, started_by/at, completed_by/at, reviewed_by/at, cancelled_by/at, notes, created_at, updated_at
- `preparation_exception_type` enum: `missing_quantity`, `missing_product`, `damaged_product`, `incomplete_order`, `other`
- `preparation_exceptions` table: id, preparation_id (FK→preparation_records CASCADE), exception_type, notes, created_by, created_at
- `warehouse.prepare` capability: assigned to Warehouse Preparation Manager, SUPER_ADMIN, CHAIRMAN, ADMIN

### Governed Functions (12 total)
- `governed_start_preparation(p_token, p_order_id, p_notes)` — validates order is `approved`, creates record + order_status_history entry
- `governed_complete_preparation(p_token, p_preparation_id, p_notes)` — sets status to `completed`
- `governed_review_preparation(p_token, p_preparation_id, p_notes)` — sets status to `reviewed`; review authority by employee code
- `governed_fail_preparation(p_token, p_preparation_id, p_failure_reason, p_notes)` — sets status to `failed`, reverts order to `approved`, records order_status_history (AD-013); `warehouse.prepare` capability
- `governed_cancel_preparation(p_token, p_preparation_id, p_notes)` — original cancel (kept for backward compatibility)
- `governed_return_to_preparation(p_token, p_preparation_id, p_notes)` — returns `completed` → `in_progress`; p_notes required (REASON_REQUIRED if empty); review authority only
- `governed_record_exception(p_token, p_preparation_id, p_exception_type, p_notes)` — records exception in `preparation_exceptions`; validates exception_type via enum; `warehouse.prepare` capability
- `get_governed_preparation_queue(p_token, p_status_filter)` — queue with governance
- `get_governed_waiting_preparations(p_token)` — approved orders without prep records
- `get_dashboard_warehouse(p_token)` — 5 counters (replaced proxy version)
- `get_warehouse_analytics(p_token)` — prepared_today, avg_prep_time, queue_size

### Dashboard Counters (5)
waiting_preparation, in_preparation, ready_for_delivery (reviewed), prepared_today, delayed_preps

### Audit Trail (AD-012)
Each preparation action records:
- **Start**: `preparation_records` started_by, started_at, notes + `order_status_history`
- **Complete**: completed_by, completed_at, notes
- **Review**: reviewed_by, reviewed_at, notes
- **Cancel**: cancelled_by, cancelled_at, notes; status → failed
- **Return**: status from `completed` back to `in_progress`; completed_by/at cleared; notes updated; reason required
- **Fail**: failure_reason stored; status → failed; order reverted to `approved`; order_status_history updated
- **Exception**: exception_type, notes, created_by, created_at in `preparation_exceptions`

All fields populated automatically by governed functions — no manual entry required.

### Operational History (AD-013)
- `order_status_history` records `approved → preparing` on start, `preparing → approved` on fail
- `preparation_records` tracks the full preparation lifecycle
- `preparation_exceptions` tracks individual exception events
- `order_modification_history` remains untouched (0 entries)

---

### Business Rules
- Credit based on configurable programs (not free-form limits)
- Program A: 100,000 EGP / 15 days; Program B: 300,000 EGP / 30 days; configurable from admin UI
- Final approval authority: محمد سعيد (WRQ1003) and ياسر توفيق (WRQ1006) only, via CREDIT_APPROVER role
- Documents collected manually outside system; system tracks 5 booleans: commercial_reg, tax_card, national_id, cheques, contract_signed
- Credit payment option hidden from customer until approval
- Contract template editable from management UI
- **Current contract template**: Temporary operational template. Requires legal/business review when official company contract becomes available.

### Workflow Stages
`draft` → `submitted` → `under_review` → `documents_received` → `approved` (or `rejected`) → `suspended` (optional) → `approved` (reactivate)

### Database Objects
- `credit_application_status` enum: draft, submitted, under_review, documents_received, approved, rejected, suspended
- `credit_programs` table: id, name, credit_limit, credit_days, terms, is_active, created_at, updated_at
- `credit_applications` table: id, customer_id, program_id, status, 5 doc booleans, doc_confirmed_by/at, submitted_at, reviewed_by/at, approved_by/at, rejection_reason, suspended_by/at, suspension_reason, created_by, created_at, updated_at
- `credit_contracts` table: id, application_id, customer_id, program_snapshot (jsonb), terms_text, signed_at, signed_by, verified_by, created_at
- `credit_contract_templates` table: id, name, template_text, is_active, updated_at
- `CREDIT_APPROVER` role: assigned to WRQ1003 + WRQ1006; holds credit.approve + credit.suspend capabilities

### Capabilities
- `credit.create` — SALES_REP, SALES_SUPERVISOR, EXECUTIVE_MANAGER, SUPER_ADMIN/CHAIRMAN/ADMIN
- `credit.submit` — same as create
- `credit.confirm_documents` — same as create
- `credit.review` — same as create
- `credit.approve` — CREDIT_APPROVER role only (WRQ1003 + WRQ1006)
- `credit.suspend` — CREDIT_APPROVER role only
- `credit.view` — all roles
- `credit.manage_programs` — SUPER_ADMIN, CHAIRMAN, ADMIN
- `credit.manage_contracts` — SUPER_ADMIN, CHAIRMAN, ADMIN

### Governance Functions (19 total)
- Program CRUD: governed_get_credit_programs, governed_create_credit_program, governed_update_credit_program, governed_toggle_credit_program
- Application lifecycle: governed_create_credit_application, governed_submit_credit_application, governed_confirm_documents, governed_review_credit, governed_approve_credit, governed_reject_credit, governed_suspend_credit, governed_reactivate_credit
- Contract: governed_sign_contract, governed_get_contract_by_application, governed_get_contract_template, governed_update_contract_template
- Views: get_governed_credit_applications, get_governed_credit_application, get_credit_dashboard_stats

### Frontend Pages
- `/credit/programs` — CreditProgramsPage: Admin CRUD for programs
- `/credit/applications` — CreditApplicationsPage: Employee follow-up queue with status filters
- `/credit/applications/:id` — CreditReviewPage: Single application detail + approve/reject/suspend/reactivate actions
- `/customer/credit` — CustomerCreditPage: Customer view of programs + submit application
- ManagementDashboard: Credit stats widget (new/under_review/docs_pending/approved/rejected/suspended)

### Approval Enforcement
- Approve/reject/suspend/reactivate guarded by `check_capability(p_token, 'credit.approve')` and `check_capability(p_token, 'credit.suspend')`
- Only CREDIT_APPROVER role has these capabilities
- Credit limit/days written to `customers` table on approval from program values
- Contract auto-created on approval with program snapshot + template terms

---

## Credit Program Module V2 (2026-06-04)

### Overview
Extends Credit Workflow Phase 1 with account management, invoice/cheque tracking, and credit reservation flow for order payment.

### New Database Objects
- `customer_credit_accounts` — one active credit account per customer, linked to a program
- `credit_invoices` — per-order invoices with due dates (one invoice per credit order)
- `credit_invoice_cheques` — one cheque per invoice (UNIQUE constraint on invoice_id)
- `credit_account_status` enum: active, suspended, closed
- `credit_invoice_status` enum: open, paid, overdue
- `cheque_status` enum: received, deposited, collected, cancelled, returned, paid_directly
- `orders.payment_method` column (varchar(20), default 'cash')

### New Capabilities (6)
- `credit.account.activate` — activate credit account from approved application
- `credit.account.suspend` — suspend active credit account
- `credit.account.reactivate` — reactivate suspended account
- `credit.cheque.manage` — record and manage credit invoice cheques
- `credit.payment.record` — record credit invoice payments
- `credit.program.manage` — create and manage credit programs

### V2 Governance Functions (10 new)
- Account: `get_governed_customer_credit_account`, `governed_activate_credit_account`, `governed_suspend_credit_account`, `governed_reactivate_credit_account`
- Invoices: `get_governed_credit_invoices`, `get_governed_credit_invoice_detail`
- Cheques: `governed_record_cheque`
- Payments: `governed_record_credit_payment`
- Order integration: `governed_reserve_credit_for_order`, `governed_release_credit_reservation`, `governed_convert_credit_reservation_to_outstanding`
- Dashboard: `get_governed_credit_dashboard`
- Auto-maintenance: `governed_auto_suspend_overdue_accounts`

### Credit Reservation Flow
1. Customer selects `credit` as payment method during checkout
2. `governed_reserve_credit_for_order` checks available credit (limit - outstanding - reserved) and reserves the amount
3. On order approval: `governed_convert_credit_reservation_to_outstanding` moves reserved→outstanding, creates invoice with due date
4. On order rejection/cancellation: `governed_release_credit_reservation` frees the reserved amount

### Auto-Suspension
- `governed_auto_suspend_overdue_accounts` daily check: marks overdue invoices, suspends accounts with past-due invoices
- To be scheduled as a cron job

### Frontend Pages (V2 additions)
- `/credit` — CustomerCreditPage: full credit dashboard (account status card with usage bar, invoices list with open/all filter, application form)
- `/credit/manage` — CreditManagementPage: 3-tab employee dashboard (stats, program management, invoices with payment recording)

### Seed Data
- 2 programs: 100K/15d, 300K/30d
- 3 accounts: active (used 40k, reserved 10k), active (used 180k, reserved 50k), suspended (overdue 200k)
- 4 invoices (1 paid, 2 open, 1 overdue) with cheques
- 1 pending application

---

## Operational Traceability Rules

### AD-012: Operational Audit Trail Rule

Every operational workflow transition must record:

| Field | Description |
|-------|-------------|
| Entity ID | The record being transitioned |
| Previous Status | Status before transition |
| New Status | Status after transition |
| Performed By | Employee who performed the action |
| Performed At | Timestamp of transition |
| Notes | Optional context or reason |

Applies to: Orders, Preparation, Preparation Review, Delivery, Collection, Returns, Credit Workflow, and any future operational workflow.

### AD-013: Order Traceability Rule

Every order must maintain two independent histories:

**1. Operational History**
Records lifecycle events such as:
- Order Created, Order Approved
- Preparation Started, Preparation Completed, Preparation Reviewed
- Shipped, Delivered, Collected, Returned

Each entry records: User, Date/Time, Notes.

**2. Modification History**
Records data changes such as:
- Product Added, Product Removed, Quantity Changed, Price Changed
- Customer Changed, Owner Changed, Representative Changed

Each entry records: User, Date/Time, Previous Value, New Value, Notes.

### Approved Operational Lifecycle

```
Approved
  → Preparation Started
    → Preparation Completed
      → Preparation Reviewed
        → Shipped
          → Delivered
            → Collected
              → Returned (if applicable)
```

### Preparation Authority

| Authority | Scope |
|-----------|-------|
| بسام (WRQ1001) — Warehouse Preparation Manager | Start Preparation, Complete Preparation |

### Preparation Review Authority

| Authority | Scope |
|-----------|-------|
| محمد عبد الباسط (REP-001) — Transportation Manager | Approve → Preparation Reviewed |
| هادى سعيد (WRQ1005) — Executive Supervisor | Approve → Preparation Reviewed |
| على سعيد (WRQ1002) — Executive Manager | Approve → Preparation Reviewed |
| محمود سعيد (WRQ1004) — Executive Manager | Approve → Preparation Reviewed |
| محمد سعيد (WRQ1003) — Chairman | Approve → Preparation Reviewed |
| ياسر توفيق (WRQ1006) — SUPER_ADMIN | Approve → Preparation Reviewed |

Preparation Review transitions the order from `Preparation Completed` to `Preparation Reviewed`, authorizing the order to move to Shipping/Delivery.

---

## Daily Deal Business Rules

### Overview

Daily Deal (صفقة اليوم) is a commercial package feature that allows Sales Manager and above to create fixed-price packages containing one or more products with configured quantities.

### Official Business Rules

| # | Rule | Details |
|---|------|---------|
| 1 | **Creation Authority** | Sales Manager and above (EXECUTIVE_MANAGER, CHAIRMAN, ADMIN, SUPER_ADMIN) may create, edit, activate, and cancel daily deals. |
| 2 | **Package Type** | Daily Deal is a commercial package, not a normal product. |
| 3 | **Composition** | A deal contains one or more products with configured quantities. |
| 4 | **Customer Visibility** | Customer sees full deal details: image, title, description, and final fixed price. |
| 5 | **Order Coexistence** | Daily Deal can be purchased together with normal products in the same order. |
| 6 | **Invoice Contribution** | Daily Deal contributes to invoice total (subtotal and net total). |
| 7 | **Tier Exclusion** | Daily Deal does NOT contribute to tier minimum target calculation. |
| 8 | **Tier Achievement** | Daily Deal does NOT contribute to tier achievement. |
| 9 | **Tier Discounts** | Daily Deal does NOT receive tier discounts. |
| 10 | **Quantity Deduction** | Deal quantity decreases by 1 per purchase. |
| 11 | **Inventory Deduction** | Product inventory is deducted from actual component products (defined in `daily_deal_items`) upon order approval. |
| 12 | **Expired Deals** | Expired deals remain visible. They display: "انتهى العرض" |
| 13 | **Sold Out Deals** | Sold out deals remain visible. They display: "نفدت الكمية" |
| 14 | **Purchase Disabled** | Purchase is disabled when a deal is expired or sold out. |

### Status Values

| Status | Meaning |
|--------|---------|
| `draft` | Initial state, not yet visible to customers |
| `scheduled` | Scheduled for future activation |
| `active` | Currently available for purchase |
| `sold_out` | Available quantity reached zero |
| `expired` | Past the `ends_at` date |
| `cancelled` | Cancelled by administrator |

### Capabilities

| Capability | Code | Assigned To |
|------------|------|-------------|
| Manage Daily Deals | `deals.manage` | EXECUTIVE_MANAGER, CHAIRMAN, ADMIN, SUPER_ADMIN (Sales Manager and above) |

### Database Objects

| Object | Type | Description |
|--------|------|-------------|
| `daily_deals` | Table | Deal header: title, image, description, fixed_price, available_quantity, dates, status, created_by |
| `daily_deal_items` | Table | Deal line items: deal_id, product_id, quantity (FK → products) |
| `order_daily_deals` | Table | Links deals to orders: order_id, deal_id, quantity, fixed_price (snapshot) |
| `governed_create_daily_deal` | Function | Create a new daily deal |
| `governed_update_daily_deal` | Function | Update an existing daily deal |
| `governed_activate_daily_deal` | Function | Activate a draft/scheduled deal |
| `governed_cancel_daily_deal` | Function | Cancel an active deal |
| `get_governed_daily_deals` | Function | List daily deals with governance |
| `get_governed_active_daily_deals` | Function | List currently active daily deals for storefront |

### Storefront Display Rules

- Active deals appear on the Daily Deal page (`/daily-deals`)
- Each deal shows: image, title, description, fixed price, remaining quantity, expiry information
- Expired deals show: "انتهى العرض"
- Sold out deals show: "نفدت الكمية"
- Purchase button is disabled when deal is expired or sold out
- Deal pricing is a single fixed price per deal (not per-unit pricing)
- Deals use a separate cart line item type (not a regular product)

---

## Flash Offer Business Rules

### Overview

Flash Offer (عرض الساعة) is a countdown-driven commercial package feature that allows Sales Manager and above to create fixed-price packages containing one or more products with configured quantities. Flash Offers differ from Daily Deals through their urgency-driven countdown behavior.

### Official Business Rules

| # | Rule | Details |
|---|------|---------|
| 1 | **Creation Authority** | Sales Manager and above (EXECUTIVE_MANAGER, CHAIRMAN, ADMIN, SUPER_ADMIN) may create, edit, activate, and cancel flash offers. |
| 2 | **Package Type** | Flash Offer is a commercial package, not a normal product. |
| 3 | **Composition** | An offer contains one or more products with configured quantities. |
| 4 | **Customer Visibility** | Customer sees full offer details: image, title, description, and final fixed price. |
| 5 | **Order Coexistence** | Flash Offer can be purchased together with normal products in the same order. |
| 6 | **Invoice Contribution** | Flash Offer contributes to invoice total (subtotal and net total). |
| 7 | **Tier Exclusion** | Flash Offer does NOT contribute to tier minimum target calculation. |
| 8 | **Tier Achievement** | Flash Offer does NOT contribute to tier achievement. |
| 9 | **Tier Discounts** | Flash Offer does NOT receive tier discounts. |
| 10 | **Quantity Deduction** | Offer quantity decreases by 1 per purchase. |
| 11 | **Inventory Deduction** | Product inventory is deducted from actual component products (defined in `flash_offer_items`) upon order approval. |
| 12 | **Countdown Expiry** | Purchase stops immediately when countdown reaches zero. |
| 13 | **Sold Out** | Purchase stops immediately when quantity reaches zero. |
| 14 | **Expired Offers** | Expired offers remain visible. They display: "انتهى العرض" |
| 15 | **Sold Out Offers** | Sold out offers remain visible. They display: "نفدت الكمية" |

### Status Values

| Status | Meaning |
|--------|---------|
| `draft` | Initial state, not yet visible to customers |
| `scheduled` | Scheduled for future activation |
| `active` | Currently available for purchase |
| `sold_out` | Available quantity reached zero |
| `expired` | Past the `ends_at` date |
| `cancelled` | Cancelled by administrator |

### Capabilities

| Capability | Code | Assigned To |
|------------|------|-------------|
| Manage Flash Offers | `flash_offers.manage` | EXECUTIVE_MANAGER, CHAIRMAN, ADMIN, SUPER_ADMIN (Sales Manager and above) |

### Database Objects

| Object | Type | Description |
|--------|------|-------------|
| `flash_offers` | Table | Offer header: title, image, description, fixed_price, available_quantity, dates, status, created_by |
| `flash_offer_items` | Table | Offer line items: offer_id, product_id, quantity (FK → products) |
| `order_flash_offers` | Table | Links offers to orders: order_id, offer_id, quantity, fixed_price (snapshot) |
| `governed_create_flash_offer` | Function | Create a new flash offer |
| `governed_update_flash_offer` | Function | Update an existing flash offer |
| `governed_activate_flash_offer` | Function | Activate a draft/scheduled offer |
| `governed_cancel_flash_offer` | Function | Cancel an active offer |
| `get_governed_flash_offers` | Function | List flash offers with governance |
| `get_governed_active_flash_offers` | Function | List currently active flash offers for storefront |

### Storefront Display Rules

- Active offers appear on the Flash Offer page (`/flash-offers`)
- Featured hero section shows nearest-expiring active offer with live countdown
- Countdown uses Africa/Cairo timezone, updates every second
- Hero background: deep navy blue (#071A3A, #0F2B5B) with gold accents (#C9A227, #E0B84D)
- Each active offer card shows: image, title, description, fixed price, remaining quantity, mini countdown
- Expired offers show: "انتهى العرض"
- Sold out offers show: "نفدت الكمية"
- Purchase button is disabled when offer is expired or sold out
- Offer pricing is a single fixed price per offer (not per-unit pricing)
- Offers use a separate cart line item type (not a regular product)

---

## Approved Architectural Decisions

| ID | Decision | Rationale |
|---|---|---|
| AD-001 | Inline CTE over get_visible_employee_ids() | SETOF uuid type broken in IN-clause; array_agg + ANY() works |
| AD-002 | No RLS, SECURITY DEFINER only | Anon key cannot be trusted; governance in function layer |
| AD-003 | Custom sessions over JWT | Simpler implementation, no Supabase Auth dependency |
| AD-004 | Anon key only in frontend | Service role key has full access; never expose |
| AD-005 | Shared unit via code-based lookup | `WHERE code = 'WRQ1002'` over `full_name` to avoid encoding issues |
| AD-006 | Capability-aware super admin check | Check employee_roles for SUPER_ADMIN/CHAIRMAN/ADMIN to bypass subtree |
| AD-007 | Proxy statuses for warehouse/transport | No DB schema migration allowed; map from existing order statuses |
| AD-008 | subtree visibility for non-admin users | Managers see own + subordinate records via recursive CTE |
| AD-009 | No migration policy | DB schema is frozen; all changes via SECURITY DEFINER functions only |
| AD-010 | Credit programs over free-form limits | Credit limit/days must come from a credit_program; no direct editing of customer credit fields |
| AD-011 | Sales authority scope by employee tier | Chairman/SUPER_ADMIN/ADMIN = full scope; Shared Unit = shared manager subtree; Sales Supervisor = team scope; SALES_REP = direct ownership only |
| AD-012 | Operational Audit Trail Rule | Every workflow transition must record entity_id, previous_status, new_status, performed_by, performed_at, notes |
| AD-013 | Order Traceability Rule | Every order must maintain two independent histories: Operational (lifecycle events) and Modification (data changes with previous/new values) |

---

## Known Constraints

1. **No status schema changes** — Order statuses lack preparation/delivery states; proxy mappings required
2. **No migration** — DB schema frozen; only function-level changes allowed
3. **No JWT** — Session tokens are UUIDs stored in localStorage; no refresh mechanism
4. **No RLS** — All access control at function layer
5. **Service role key in Node.js only** — Never in frontend code
6. **Anon key is publishable** — It's designed to be public; governance is the security layer
7. **Arabic encoding** — Names in DB may appear garbled depending on client encoding
8. **No git history** — Repository was never committed; no rollback capability

### Mobile-First UI Direction
- All operational pages must use card-based layouts (no `<table>` on mobile)
- Action buttons must have minimum 40px touch targets
- Padding must use the AppLayout `px-4` standard
- List pages must use `space-y-2` card stacks rather than horizontal tables
- Conversion completed for WarehousePage and WarehouseReviewPage

---

## Current System Status

| Metric | Value |
|---|---|---|
| Employees | 16 |
| Customers | 25 |
| Orders | 41 |
| Identities | 41 |
| Roles | 24 (+1: CREDIT_APPROVER) |
| Capabilities | 49 (+1: deals.manage) |
| Role-Capability Mappings | 400+ |
| Active sessions | varies (24h expiry) |
| DB functions | 105+ (warehouse, delivery, credit, daily deals, governance, dashboards, auth) |
| Frontend pages | 38+ route entries |
| Migration files | 13 SQL files |
| TypeScript | `tsc --noEmit` passes clean |

---

## Documentation Governance

**Rule**: No task is considered complete until all of:
1. ✅ Implementation completed
2. ✅ Validation completed
3. ✅ SYSTEM_BLUEPRINT.md updated
4. ✅ PROJECT_CHANGELOG.md updated

This applies to: Architecture, Governance, Ownership, Authentication, Pricing, Workflow, Runtime, Analytics, Reporting, Database, UI/UX, Operational processes, and all other work scopes.

### Constitution Reference

The **Project Operating Constitution** (Section: ACTIVE_TARGETS) governs all execution behavior:

- **Section A–C**: Sources of truth and repository restrictions
- **Section D**: Scope discipline — work only within requested scope
- **Section E**: Missing information protocol — stop and ask, do not assume
- **Section F**: Documentation governance — both files must be updated
- **Section G**: Conflict protocol — stop and report, do not choose
- **Section H**: Execution philosophy — prefer execution over investigation

### Execution Efficiency

Default output: `Completed` | `Blocked` | `Required Decision` only.

---

## Visual Design Standard

**Reference File**: `design-reference/app-ui-reference.png`

The visual reference file is the official design standard for all screens. Do not treat as inspiration — treat as specification.

### Brand Colors

| Token | Value | Usage |
|---|---|---|
| Primary Background | `#071B4D` | App shell, main backgrounds |
| Secondary Background | `#0B3D91` | Cards, sections, surfaces |
| Primary Accent | `#C9A227` | Buttons, active states, key UI |
| Secondary Gold | `#E0B85A` | Subtle highlights, secondary text |
| Text Primary | `#FFFFFF` | Body text, headings |
| Text Secondary | `rgba(255,255,255,0.6)` | Labels, descriptions |
| Text Muted | `rgba(255,255,255,0.35)` | Placeholders, hints |

### Design Language

- **Style**: Premium B2B enterprise — executive, clean, mobile-first
- **Cards**: Glass effect (`rgba(255,255,255,0.04)` background, `blur(12px)`, 22px radius, 1px gold border at 15% opacity, soft deep shadow)
- **Inputs**: Dark blue background (`rgba(255,255,255,0.06)`), 14px radius, gold focus ring (`rgba(201,162,39,0.15)`), 18px padding
- **Primary Buttons**: Gold gradient (`#C9A227 → #E0B85A`), dark text (`#071B4D`), 16px radius, 16px padding
- **Secondary Buttons**: Transparent, 1.5px gold border at 30% opacity, gold text, 16px radius
- **Loading**: Gold circular spinner (`3px border, 0.8s spin`), gold progress line (`120px wide, 2px, sweep animation`)
- **Typography**: Inter/system-ui, white text, generous spacing

### Screens Covered

- Splash Screen
- Authentication Verification
- Login Page
- Registration Page
- Install PWA Banner
- Offline Screen
- Application Shell (TopBar, Main Content, BottomNav)
- Dashboard Headers
- All Navigation Components

### Icons

All icons use the `/pwa/` directory assets (replicated to `/public/icons/`). The app icon is a gold "أ" (Alef) on a rounded square, representing Al-Ahram.

---

*Last updated: 2026-06-04* (Visual Design Standard)
